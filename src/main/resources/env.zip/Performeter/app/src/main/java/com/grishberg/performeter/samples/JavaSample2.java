package com.grishberg.performeter.samples;

/* place your includes there */

public class JavaSample2 implements Runnable {
    private Object result;

    @Override
    public void run() {
        /* place your code there */
    }
}
