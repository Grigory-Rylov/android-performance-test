package com.grishberg.performeter.samples

/* place your includes there */

class KotlinSample2 : Runnable {
    private var result: Any? = null

    override fun run() {
        /* place your code there */
    }
}
