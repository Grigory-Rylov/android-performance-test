cd env/android-performeter-sample
./gradlew clean assembleRelease