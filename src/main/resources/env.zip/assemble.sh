cd env/Performeter
./gradlew clean assembleRelease