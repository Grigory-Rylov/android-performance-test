# android-performeter-sample
Sample android application for measuring code performance

Used as sample app in https://github.com/Grigory-Rylov/android-performance-test
