package com.grishberg.performeter.samples;

import com.grishberg.performeter.RunnableWithResult;

/* place your includes there */

public class JavaSample2 implements RunnableWithResult {
    private Object result;

    /* place your fields and methods there */

    @Override
    public void init() {
        /* place your init code there */
    }

    @Override
    public void run() {
        /* place your code there */
    }

    @Override
    public Object getResult() {
        return result;
    }
}
