package com.grishberg.performeter.samples

import com.grishberg.performeter.RunnableWithResult

/* place your includes there */

class KotlinSample2 : RunnableWithResult {
    private var result: Any? = null

    /* place your fields and methods there */

    override fun run() {
        /* place your code there */
    }

    override fun getResult(): Any? = result
}
